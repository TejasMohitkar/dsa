// global (SLL) Singly Linear LinkedList
#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
    int data; 
    struct node *next;
}node_t;
node_t *head; // struct node *head=NULL;
node_t* create_node(int value);
void add_first(int value);
int main()
{

    add_first(30);
    add_first(20);
    add_first(10);

    return 0;
}

node_t* create_node(int value)
{
    node_t *new_node=NULL;
    new_node= (node_t*)malloc(1*sizeof(node_t));
    if( new_node==NULL)
    {
        printf("\n unable to allocate memory");
        exit(0);
    }
    else 
    {
        new_node->data= value;
        new_node->next=NULL;
    }
    return new_node;
}
void add_first(int value)
{
    node_t *newnode=NULL;
    newnode=create_node(value);
    if( head== NULL)  // if linked list is empty
    {
        head= newnode;  // store address of new node into head pointer
    }
    else 
    {
        newnode->next= head; // store the address of 1st node into next of newnode
        head= newnode; // store the address of new node into head pointer
    }
    return;

}