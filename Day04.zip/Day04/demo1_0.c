#include<stdio.h>
struct node
{
    int data;  // data
    struct node *next;
}; // self ref structure  ---> linked list and tree