#include<stdio.h>
typedef struct node
{
    int data;  // data
    node_t* next; // error: unknown type name ‘node_t’
}node_t; // 