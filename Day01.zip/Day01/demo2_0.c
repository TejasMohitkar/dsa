
// accept and print array
#include<stdio.h>
#define SIZE 6
void accept_array(int a[], int size);
void display_array(const int *a, int size);
int linear_search(const int a[], int size, int key);
int main(void)
{
    int arr[SIZE], find, ans;
    printf("\n enter array elements :\n");
    accept_array(arr,SIZE);

    printf("\n  array elements :\n");
    display_array(arr,SIZE);
    
    printf("\n Enter element to find=");
    scanf("%d", &find);
    
    ans=linear_search(arr,SIZE, find);
    if( ans == -1)
        printf("\n %d is not found in array ", find);
    else 
        printf("\n %d is found in array at %d position ", find, ans);


    return 0;
}
int linear_search(const int a[], int size, int key)
{
    int index;
    for( index=0; index<size; index++)
    {
        if( key== a[index])
            return index;  // if key found retun index

    }
    return -1; // if key not found return -1

}
void accept_array(int a[], int size)
{
    int index;
    for(index=0; index<size; ++index)
    {
        printf("\n a[%d]", index);
        scanf("%d", &a[index]);
    }
    return;
}
void display_array(const int *a, int size)
{
    int index;
    for(index=0; index<size; index++)
    {
        printf("\n a[%d]  %5d   [%u] ", index, a[index], &a[index]);
    }
    return;
} // a[index] == *(a+index)
  // index[a] == *(index+a)









