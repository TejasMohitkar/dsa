#include<stdio.h>
int binary(int n);
int main(void)
{
    int no=33, ans=binary(no);
    printf("\n%d=%d",no, ans );
    return 0;
}
int binary(int n)
{
    if(n==1)
       return 1;
     else 
        //return binary(n/2)*10+ n%2;
        //return 10*binary(n/2)+ n%2;
        return  n%2+ 10*binary(n/2);
  
}

/*
int binary(int n)
{
    int res=0;
    if(n==1)
    {
        printf("\nbinary(%d)=1", n);
        return 1;
    }
    else 
    {
        res= binary(n/2)*10+ n%2;
        printf("\nbinary(%d) = %d", n, res);
    }
    return res;
}
*/