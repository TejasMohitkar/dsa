/*
ccat - 7 questions (4 to 5 theory and 2 to 3 coding)

sorting and searching  (2 questions)
    sorting - selection , buble sort , insertion , merge and quick sort
    searching -   linear search  (strchr) , binary search (sorted in asc)    
stack and queue -  (2 questions)
linked list        (1/2 questions)
tree, graph and hashing     (1/2 questions)
*/

// accept and print array
#include<stdio.h>
#define SIZE 6
void accept_array(int a[], int size);
void display_array(const int *a, int size);
int main(void)
{
    int arr[SIZE];
    printf("\n enter array elements :\n");
    accept_array(arr,SIZE);

    printf("\n  array elements :\n");
    display_array(arr,SIZE);
    
    return 0;
}
void accept_array(int a[], int size)
{
    int index;
    for(index=0; index<size; ++index)
    {
        printf("\n a[%d]", index);
        scanf("%d", &a[index]);
    }
    return;
}
void display_array(const int *a, int size)
{
    int index;
    for(index=0; index<size; index++)
    {
        printf("\n a[%d]  %5d   [%u] ", index, a[index], &a[index]);
    }
    return;
} // a[index] == *(a+index)
  // index[a] == *(index+a)









