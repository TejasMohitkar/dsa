
// accept and print array  
// insertion_sort sort asc using macro
#include<stdio.h>

#define SIZE 6
void accept_array(int a[], int size);
void display_array(const int *a, int size);
void insertion_sort(int a[], int size);

int main(void)
{
    int arr[SIZE];
    printf("\n enter array elements :\n");
    accept_array(arr,SIZE);

    printf("\n  array elements :\n");
    display_array(arr,SIZE);

    insertion_sort(arr, SIZE);
    printf("\n  after asc sort  of array elements 1_3 :\n");
    display_array(arr,SIZE);

    
    return 0;
}
void insertion_sort(int a[], int size)
{
    int i, j, key;
    for( i=1;i<size; i++)
    {
        j= i-1;
        key= a[i];

        display_array(a,size);

        //while( j>=0 && key<= a[j])  // asc
        while( j>=0 && key>= a[j])  // desc
        {
            // shift elements towords it right side
            a[j+1]=a[j];
            j--;
        }
        // insert key into array
        a[j+1]=key;
        printf("\n key=%d j=%d", key, j);
        display_array(a,size);
    }


    return;

}
void accept_array(int a[], int size)
{
    int index;
    for(index=0; index<size; ++index)
    {
        printf("\n a[%d]", index);
        scanf("%d", &a[index]);
    }
    return;
}
void display_array(const int *a, int size)
{
    int index;
    printf("\n===========================\n");
    for(index=0; index<size; index++)
    {
        printf("\n a[%d]  %5d   [%u] ", index, a[index], &a[index]);
    }
    printf("\n===========================\n");
    return;
} // a[index] == *(a+index)
  // index[a] == *(index+a)



