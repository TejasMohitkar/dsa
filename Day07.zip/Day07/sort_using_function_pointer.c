
#include<stdio.h>
#define SIZE 6

void accept_array(int a[], int size);
void display_array(const int *a, int size);
void selection_sort(int a[], int size,  int (*fp)(int num1, int num2));
int asc(int n1, int n2);
int desc(int n1, int n2);

int main(void)
{
    int arr[SIZE];
    int (*funptr)(int num1, int num2);
    printf("\n enter array elements :\n");
    accept_array(arr,SIZE);

    printf("\n  array elements :\n");
    display_array(arr,SIZE);

    funptr=asc;
    selection_sort(arr, SIZE, funptr);
    printf("\n  after asc sort  of array elements :\n");
    display_array(arr,SIZE);
  
    funptr=desc;
    selection_sort(arr, SIZE, funptr);
    printf("\n  after desc sort  of array elements :\n");
    display_array(arr,SIZE);
    
    return 0;
}
int asc(int n1, int n2)
{
    printf("\n asc");
    return n1-n2;
}
int desc(int n1, int n2)
{
    printf("\n desc");
    return n2-n1;
}

void selection_sort(int a[], int size, int (*fp)(int num1, int num2))
{
    int i, j, temp;
    for(i=0; i<size; i++ ) // outer loop for selection of index
    {
        for(j=i+1; j<size; j++) //inner loop for compare with index of array
        {
            printf("\n a[%d] %d a[%d] %d", i, a[i], j, a[j]);
            if( fp(a[i], a[j])>0)  
            {
                // way 1 swap using temp variable
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
        if( i< (size-1))
            printf("\n itration =%d", i+1);
    }
    return;

}
void accept_array(int a[], int size)
{
    int index;
    for(index=0; index<size; ++index)
    {
        printf("\n a[%d]", index);
        scanf("%d", &a[index]);
    }
    return;
}
void display_array(const int *a, int size)
{
    int index;
    for(index=0; index<size; index++)
    {
        printf("\n a[%d]  %5d   [%u] ", index, a[index], &a[index]);
    }
    return;
} // a[index] == *(a+index)
  // index[a] == *(index+a)



// qsort -- can sort array of any data type (int /char/float/ struture) stdlib.h  