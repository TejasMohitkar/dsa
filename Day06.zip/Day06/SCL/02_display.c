//Singly Circular LinkedList with head and tail pointer
#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
}; 
typedef struct node node_t;
node_t *head;// struct node *head=NULL;
node_t *tail;// struct node *tail=NULL;
node_t* create_node(int value);
void add_last(int value);
void display_list();
int main(void)
{ 
    display_list(); // list is empty
    add_last(10);   
    display_list();  // 10---> 
    add_last(20);
    display_list();  // 10---> 20---> 
    add_last(30);
    display_list();// 10---> 20--->30---> 

    add_last(40);
    display_list();// 10---> 20--->30---> 40--->

    return 0;
}
node_t* create_node(int value)
{
    node_t *new_node= NULL;
    new_node= (node_t*)malloc(1*sizeof(node_t));
    if( new_node== NULL)
    {
        printf("\n unable to allocate memory ");
        return 0;
    }
    else 
    {
        new_node->data=value;
        new_node->next= NULL;
    }
    return new_node;        
}
void add_last(int value)
{
    node_t * newnode=NULL;
    newnode= create_node(value);
    if( head == NULL)
    {
        head = newnode;  // store address of new node into head(1st) pointer
        tail = newnode;  // store address of new node into tail(last) pointer
        newnode->next= head; // store address of 1st node(head) into next pointer of new node
    }
    else 
    {
        newnode->next= head; // store the address of 1st node( head) into next pointer of new node
        tail->next= newnode; // store the address of new node into last nodes (tails) next pointer
        tail= newnode;  // store the address of new node into tail pointer
    }
    return;
}

void display_list()
{   
    node_t *trav=NULL;
    if( head == NULL)
    {
        printf("\n list is empty");
    }
    else 
    {
        trav= head;  //store address of 1st node into trav pointer
        do
        {
            printf("%d---->", trav->data); // print data of trav node
            trav= trav->next;  // trav to next
        }while(trav!=head); // check untill you reach last-next == head (1 st node)

    }
    printf("\n");
    return;
}



















