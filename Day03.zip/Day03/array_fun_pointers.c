#include<stdio.h>
int sum(int n1, int n2);
int minus(int n1, int n2);
int multiply(int n1, int n2);
int main(void)
{
    int no1=10, no2=20, ans=0, index;
    int (*funptr[3])(int num1, int num2);
/* funptr is array of 3 function pointers, where each
pointer points to a function which receives two parameters and
return integer */
    //ans= sum(no1,  no2);
   // printf("\n %d + %d = %d", no1, no2 ,ans);

    funptr[0]= sum; // store address of sum into funtion pointer funptr
    funptr[1]= minus; // store address of minus into funtion pointer funptr
    funptr[2]= multiply; // store address of multiply into funtion pointer funptr

    for(index=0; index<3; index++)
    {
        printf("\n %d ", funptr[index](20,10));
    }

    funptr[2]= sum; // store address of sum into funtion pointer funptr
    funptr[0]= minus; // store address of minus into funtion pointer funptr
    funptr[1]= multiply; // store address of multiply into funtion pointer funptr

    for(index=0; index<3; index++)
    {
        printf("\n %d ", funptr[index](20,10));
    }
    return 0;
}
int sum(int n1, int n2)
{
    printf("\nsum function is called \n");
    return n1+n2;
}
int minus(int n1, int n2)
{
    printf("\nminus function is called \n");
    return n1-n2;
}
int multiply(int n1, int n2)
{
    printf("\n multiply function is called \n");
    return n1*n2;
}

