//Doubly Linear LinkedList (DLL) with head amd tail pointer
#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    struct node * prev;
    int data;
    struct node * next;
}node_t;
node_t *head; // struct node  * head= NULL;  // store address of 1st node
node_t *tail; // struct node  * tail= NULL;  // store address of last node
node_t* create_node(int value);
void add_last(int value);
void display_list();
void add_first(int value);
int main(void)
{
    display_list(); // list is empty
    add_first(40);   
    display_list();  // 40---> NULL
    add_first(30);
    display_list();  // 30---> 40---> NULL
    add_first(20);
    display_list();// 20---> 30--->40---> NULL

    add_first(10);
    display_list();// 10---> 20--->30--->40---> NULL
    
    
    return 0;

}
node_t* create_node(int value)
{
    node_t * new_node=NULL;
    new_node= (node_t*)malloc(1*sizeof(node_t));
    if( new_node== NULL)    
    {
        printf("\n unable to allocat memory");
        exit(0);
    }
    else 
    {
        new_node->prev=NULL;
        new_node->data= value;
        new_node->next= NULL;
    }
    return  new_node;
}
void add_first(int value)
{

    node_t *newnode=NULL;
    newnode= create_node(value);
    if( head== NULL)
    {
        head= newnode;
        tail= newnode;
    }
    else 
    {
        newnode->next= head; // store the address of 1st( head) node  into new nodes next pointer
        head->prev= newnode; // store the address of new node into prev pointer of 1st node (head)
        head= newnode; // store the address of new node into head pointer
    }
    return;
}
void display_list()
{
    node_t * trav=NULL;
    if( head== NULL)
        printf("\n list is empty \n");
    else 
    {
        printf("\n ====================================\n");
        printf("\n Forword display \n");
        trav=head;  // store the address of 1st node( head) into trav pointer
        while(trav!=NULL)
        {
            printf("%5d--->", trav->data);  // print data of current node
            trav= trav->next;  // gotpo next node in linked linked
        }
        printf("\n");


        printf("\n Backword display \n");
        trav=tail;  // store the address of last node( tail) into trav pointer
        while(trav!=NULL)
        {
            printf("<---%5d", trav->data);  // print data of current node
            trav= trav->prev;  // gotpo prev node in linked linked
        }
        printf("\n ====================================\n");
    }
    return;
}
void add_last(int value)
{
    node_t * newnode=NULL;
    newnode= create_node(value);
    if( head== NULL) /// if list is empty
    {
        head=newnode; // store the address of new node (1st) node into head
        tail= newnode; // store the address of new node (1st) node into tail
    }
    else 
    {
        newnode->prev= tail;  // store the address of last node (tail) into prev pointer of new node
        tail->next= newnode;  // store the address of new node into next pointer of last (tail) node
        tail=newnode; // store the address of new node into tail pointer
    }


}