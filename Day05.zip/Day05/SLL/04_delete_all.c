// global (SLL) Singly Linear LinkedList
#pragma pack(1)
#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
    int data; 
    struct node *next;
}node_t;
node_t *head; // struct node *head=NULL;
node_t* create_node(int value);
void add_first(int value);
void display_list();
void add_last(int value);
void add_at_position(int position, int value);
int count_nodes();
void trav_rev(node_t *trav);
int del_first();
int del_last();
int del_at_position(int position);

void free_list();

int main()
{
    int data;
    display_list();
    add_last(10);  
    display_list();  // 10--->

    //data= del_first();
    //printf("\n node with %d data  deleted from  linked list", data);
    //display_list();//   empty

    //return 0;
    
    add_last(20);
    display_list(); // 10--->20--->
    add_last(30);
    display_list();// 10--->20--->30--->
    add_last(40);
    display_list();// 10--->20--->30--->40--->
     add_last(50);
    display_list();// 10--->20--->30--->40--->50----->

      data= del_at_position(3);
    printf("\n node with %d data  deleted from  linked list", data); //30
    display_list();// 10--> 20--->40--->50--->
    

/*    data= del_at_position(1);
    printf("\n node with %d data  deleted from  linked list", data); //10
    display_list();// 20--->30--->40--->50--->
    
    data= del_at_position(4);
    printf("\n node with %d data  deleted from  linked list", data); // 50
    display_list();// 20--->30--->40----->
  */  
    free_list();
    return 0;
}
void free_list()
{
    int value=0;
    while (count_nodes())  // while(5) while(4) while(3)  while(2) while(1) while(0)
    {
        value= del_first();
        printf("\n node with %d data  deleted from  linked list", value);
    }
    printf("\n linked list is freed \n");
    return;
}
int del_at_position(int position)
{
    int i, value;
    node_t *trav=NULL, *temp=NULL;
    if( position==1 )
      value= del_first();
    else if (position== count_nodes())
    {
        value= del_last();
    }
    else 
    {
        trav= head; // store address of 1st node (head) into trav pointer
        for( i=1; i<position-1; i++)  // trav till position-1 nodes 
        {
            trav=trav->next; // goto next node
        }
        temp= trav->next; // store the address of node which u want to delete
        trav->next= temp->next;  // store address of next node which u want to delele into trav 
        value= temp->data;  // store data of that node which u want to delete
        free(temp);  // delete temp from heap
        temp=NULL;  // assign null to temp

    }
    return value;

}
int del_last()
{
    int value=0;
    node_t *prev=NULL, *trav=NULL;
    if( head== NULL)
        printf("\n list is empty");
    else 
    {
        trav= head;   // store address of 1st node (head) into trav  pointer
        while( trav->next!=NULL)  // trav till last node of linked list
        {
              prev= trav;  //  store address of trav pointer into prev pointer
              trav= trav->next;   // trav to next node in linked list
        }
        if( prev== NULL)  // if linked list has 1 node then prev== NULL
            head= NULL;  // over right address of head with NULL
        else
            prev->next=NULL; // break the connection of last node with linked list
        value= trav->data; // store data part of last node into value
        free(trav);  // delete last node from heap
        trav=NULL;

    }
    return value;
}
int del_first()
{
    node_t *temp=NULL;
    int value=0;
    if( head== NULL)
    {
        printf("\n linked list is empty");
        return -1;
    }
    else 
    {
        temp= head;  // store the address of 1st node(head) into temp pointer
        head= head->next; // goto next node in the linked list if present
        value= temp->data; // store data part of temp into value
      //free(temp);  // delete memory from heap
      //temp= NULL;  //assign NULL to temp to avoid dangling pointer issue

    }
    return value;
}
void trav_rev(node_t *trav)
{
    if( trav==NULL)
        return;
    else 
        trav_rev(trav->next);
    printf("<---%d", trav->data);
    return;
}
void add_at_position(int position, int value)
{
    node_t *newnode=NULL, *trav=NULL;
    int i;
    if(position==1)
    {
        add_first(value);  // call function of add 1st
    }
    else if( position== (count_nodes()+1))
    {
        add_last(value); // call function of add last
    }
    else 
    {
         newnode= create_node(value);
         trav= head;  // store address of 1st node(head) into trav pointer
         for( i=1; i<position-1; i++)
         {
            trav= trav->next; // go to next node of liked list
         }
         newnode->next= trav->next; // store the address of trav->next into new nodes next pointer
         trav->next=newnode;  // store the address of new node into trav->next pointer
    }
    return;

}
int count_nodes()
{
    node_t * trav=NULL;
    int counter=0;
    if( head== NULL)
        printf("\n list is empty \n");
    else 
    {
        trav=head;  // store the address of 1st node( head) into trav pointer
        while(trav!=NULL)
        {
            counter++;//counter=counter+1;
            trav= trav->next;  // gotpo next node in linked linked
        }
        printf("\n");
    }
    return counter;
}
void add_last(int value)
{
    node_t * newnode =NULL;
    newnode= create_node(value);
    if( head == NULL) // if list is empty
    {   
        head= newnode;  // store address of new node into head pointer
    }
    else
    {
        node_t *trav=head;  // store the address of 1st node(head) into trav pointer
        while (trav->next!=NULL) // trav till last node linked list
        {
            trav=trav->next; // go to next node of linked list
        }
        trav->next= newnode; //store the address of new node into trav->next pointer

    }
    return;
}
void display_list()
{
    node_t * trav=NULL;
    if( head== NULL)
        printf("\n list is empty \n");
    else 
    {
        trav=head;  // store the address of 1st node( head) into trav pointer
        while(trav!=NULL)
        {
            printf("%5d--->", trav->data);  // print data of current node
            trav= trav->next;  // gotpo next node in linked linked
        }
        printf("\n");
    }
    return;
}
node_t* create_node(int value)
{
    node_t *new_node=NULL;
    new_node= (node_t*)malloc(1*sizeof(node_t));
    if( new_node==NULL)
    {
        printf("\n unable to allocate memory");
        exit(0);
    }
    else 
    {
        new_node->data= value;
        new_node->next=NULL;
    }
    return new_node;
}
void add_first(int value)
{
    node_t *newnode=NULL;
    newnode=create_node(value);
    if( head== NULL)  // if linked list is empty
    {
        head= newnode;  // store address of new node into head pointer
    }
    else 
    {
        newnode->next= head; // store the address of 1st node into next of newnode
        head= newnode; // store the address of new node into head pointer
    }
    return;

}