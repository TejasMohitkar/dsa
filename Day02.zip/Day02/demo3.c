#include<stdio.h>
int sum(int n1, int n2);
int main(void)
{
    int no1=10, no2=20, ans=0;
    int (*funptr)(int num1, int num2);

    ans= sum(no1,  no2);
    printf("\n %d + %d = %d", no1, no2 ,ans);

    funptr= sum; // store address of sum into funtion pointer funptr
    ans= (*funptr)(no1, no2);
    printf("\n using old way of funptr %d + %d =%d", no1, no2, ans);
    
    ans= funptr(no1, no2);
    printf("\n using new way of funptr %d + %d =%d", no1, no2, ans);

    return 0;
}
int sum(int n1, int n2)
{
    printf("\nsum function is called \n");
    return n1+n2;
}