
// accept and print array  
// optimize bubble sort asc desc ()
#include<stdio.h>
#define SIZE 6
void accept_array(int a[], int size);
void display_array(const int *a, int size);
void bubble_sort_asc(int a[], int size);
int main(void)
{
    int arr[SIZE];
    printf("\n enter array elements :\n");
    accept_array(arr,SIZE);

    printf("\n  array elements :\n");
    display_array(arr,SIZE);

    bubble_sort_asc(arr, SIZE);
    printf("\n  after asc sort  of array elements :\n");
    display_array(arr,SIZE);

    
    return 0;
}
void bubble_sort_asc(int a[], int size)
{
    int i, j, temp, flag=0;
    for(i=0; i<size; i++ ) // outer loop 
    {
        for(j=0; j<size-i-1; j++) //inner loop for compare with j and j+1
        {
            printf("\n a[%d] %d a[%d] %d", j, a[j], j+1, a[j+1]);
            if( a[j]>a[j+1])   //asc
            //if( a[j]<a[j+1])   //desc
            {
                // way 1 swap using temp variable
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                flag=1;
            }
        } // end  of inner loop
        if( i< (size-1))
            printf("\n itration =%d", i+1);
        if( flag==0)
            break;  // go out of outer loop as array is allready sorted
    }// end of outer loop
    return;

}
void accept_array(int a[], int size)
{
    int index;
    for(index=0; index<size; ++index)
    {
        printf("\n a[%d]", index);
        scanf("%d", &a[index]);
    }
    return;
}
void display_array(const int *a, int size)
{
    int index;
    for(index=0; index<size; index++)
    {
        printf("\n a[%d]  %5d   [%u] ", index, a[index], &a[index]);
    }
    return;
} // a[index] == *(a+index)
  // index[a] == *(index+a)



{
    {
        ( ( ()) )
    }
}
